package com.agrosellnova.Agrosellnova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgrosellnovaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgrosellnovaApplication.class, args);
	}

}
